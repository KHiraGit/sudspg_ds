2JCIE-BU01 用サンプルプログラム

● 概要
　Python で作成したサンプルプログラムです。
　シリアル通信とBluetooth のpython モジュールを追加インストールすることで、
　Windowsでも、raspberry pi などのLinux上でも使用できます。
  動作はPython 3.9 および3.11で確認しています。
  すべてコマンドプロンプトなどコンソール画面で動かします。
　それぞれ独立したプログラムになっていますので2JCIE-BU01の動作確認のため使用することもできます。


● 準備
　* python のインストールが必要です。

  * また、シリアル通信モジュールpyserial とBluetoothモジュール bleak が必要です。
　  python本体のインストール後、pipで各モジュールをインストールしてください。
	(Windowsの場合)
	py -m pip install pyserial
	py -m pip install bleak

	(そのほかの環境の場合、お使いの環境にもよりますが、多くは以下でインストールできると思われます）
	python -m pip install pyserial
	python -m pip install bleak

　* Windowsの場合:
	環境センサのUSBドライバを以下のサイトからダウンロードし、インストールしてください。
		https://components.omron.com/jp-ja/products/sensors/iot_sensors/environment-sensors/2jcie-bl/software_lisense
		インストール方法は、同じサイトにある「USBドライバ インストールマニュアル」を参照してください。

	パソコンの設定ウインドウでbluetoothをオンにしてください。

  * raspberry pi OS の場合:
	環境センサをUSBポートに接続した後、以下のコマンドを実施してください。
		su
		modprobe ftdi_sio
		echo "0590 00d4" > /sys/bus/usb-serial/drivers/ftdi_sio/new_id
		exit
	/dev ディレクトリに ttyUSB0 (0は違う数字かもしれません) ができているはずです。
	サンプルプログラムで serial_port を指定する時は、このデバイスファイル (/dev/ttyUSB0)を指定してください。

	

● サンプルプログラム
　以下の４つです。コマンドプロンプトなどコンソール画面から動作させることができます。
	ble_2jcie-bu_adv.py	bluetooth通信で2JCIE-BU01からアドバタイズされるデータを受信し表示ます。
	ble_2jcie-bu_mode.py	bluetooth通信で2JCIE-BU01のアドバタイズモードなどを変更します。
	usb_2jcie-bu_env.py	usb経由で2JCIE-BU01で計測した環境データを取得し表示します。
	usb_2jcie-bu_mode.py	usb経由で2JCIE-BU01のアドバタイズモードなどを変更します。

 
 * ble_2jcie-bu_adv.py
	使用法:  ble_2jcie-bu_adv.py

	bluetooth通信で受信できる2JCIE-BU01からのアドバタイズデータを読み取って表示します。
	Ctrl-Cが押されるまで、連続して受信し続けます。

	使用例:  (Windowsコマンドプロンプトの場合）
		C:\Users\someone>  py ble_2jcie-bu_adv.py 
			bluetoothで受信できるすべての2JCIE-BU01からのアドバタイズデータを読み取って表示します。

 * ble_2jcie-bu_mode.py
	使用法:  ble_2jcie-bu_mode.py address [-m MODE] [-a ADV]

	address で指定された2JCIE-BU01の動作モード、アドバタイズモードを切り替えます。
	-m MODE も-a ADV も指定されなかったときは、現在のモードを表示して終了します。

		address	2JCIE-BU01 のbluetoothアドレスです。12:34:56:78:9A:BC の形式です。
		-m MODE	動作モード(MODE=0,1)です。 UUID 0x5117 を使用して切り替えます。
		-a ADV	アドバタイズモード(ADV=1～5)です。UUID 0x5115を使用して切り替えます。
			動作モードとアドバタイズモードは、ユーザーズマニュアルを参照してください。

	使用例:  (Windowsコマンドプロンプトの場合）
		C:\Users\someone>  py ble_2jcie-bu_mode.py E8:C8:DF:82:5e:39 -m 0 -a 3
			bluetoothアドレスが E8:C8:DF:82:5e:39 である2JCIE-BU01の
				動作モードを0 (normal mode)、
				アドバタイズモードを3 (Sensor data & Calculation data)
			に変更します。

 * usb_2jcie-bu_env.py
	使用法:  usb_2jcie-bu_env.py serial_port

	USBポートに接続されている2JCIE-BU01から測定データを読み取り表示します。
	Ctrl-Cが押されるまで、連続して受信し続けます。

		serial_port	2JCIE-BU01が接続されているシリアルポートです。
				Windowsでは com3 など、Linux では /dev/ttyUSB0 などになります。
				実際のポート名はデバイスマネージャなどで確認してください。

	使用例:  (Windowsコマンドプロンプトの場合）
		C:\Users\someone>  py usb_2jcie-bu_env.py com3
			シリアルポート com3 に接続されている2JCIE-BU01から環境データを読み取って表示します。

 * usb_2jcie-bu_mode.py
	使用法:  usb_2jcie-bu_mode.py serial_port [-m MODE] [-a ADV]

	serial_portで指定された2JCIE-BU01 の動作モード、アドバタイズモードを切り替えます。
	-m MODE も-a ADV も指定されなかったときは、現在のモードを表示して終了します。

		serial_port	環境センサが接続されているシリアルポートです。
				Windowsでは com3 など、Linux では /dev/ttyUSB0 などになります。
				実際のポート名はデバイスマネージャなどで確認してください。
		-m MODE	動作モード(MODE=0,1)です。 アドレス 0x5117 を使用して切り替えます。
		-a ADV	アドバタイズモード(ADV=1～5)です。アドレス 0x5115 を使用して切り替えます。

	使用例:  (Windowsコマンドプロンプトの場合）
		C:\Users\someone>  py usb_2jcie-bu_mode.py com3 -m 0 -a 3
			シリアルポート com3 に接続されている2JCIE-BU01の
				動作モードを0 (normal mode)、
				アドバタイズモードを3 (Sensor data & Calculation data)
			に変更します。

